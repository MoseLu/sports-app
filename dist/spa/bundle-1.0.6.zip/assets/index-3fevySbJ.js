function t(o){return o}export{t as b};
